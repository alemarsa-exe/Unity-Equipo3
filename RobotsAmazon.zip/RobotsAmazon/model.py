
from agent import Shelf, Floor, Robot, Wall

from mesa import Agent, Model 

from mesa.space import MultiGrid

from mesa.time import SimultaneousActivation

from mesa.datacollection import DataCollector

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as animation
plt.rcParams["animation.html"] = "jshtml"
matplotlib.rcParams['animation.embed_limit'] = 2**128

import numpy as np
import pandas as pd

import time
import datetime
import math
import random

def get_grid(model):
  grid = np.zeros((model.grid.width, model.grid.height))
  for cell in model.grid.coord_iter():
    cell_content, x, y = cell
    for content in cell_content:
      if isinstance(content,Shelf):
        grid[x][y] = content.stacks 
      elif isinstance(content,Robot):
        grid[x][y] =  9
      elif isinstance(content,Floor):
        if content.isBox:
          grid[x][y] = 7
        else:
          grid[x][y] = 8
      else:
        grid[x][y] = 6
  return grid


class StorageModel(Model):
  def __init__(self, W, H, boxes):
    self.running = False
    self.nBoxes = boxes
    self.boxesLeft = boxes
    self.W = W
    self.H = H
    self.generations = 0
    self.nShelves = math.ceil(boxes / 5)
    self.shelves = 0
    self.shelfPos = (0,0)
    self.emptyFloor = W*H - boxes 

    self.grid = MultiGrid(H,W,False)
    self.schedule = SimultaneousActivation(self)

    for i in range(self.nBoxes):
      emptyGridPos = self.grid.find_empty()
      newBox = Floor(i+self.nShelves,emptyGridPos,True,self)
      self.schedule.add(newBox)     
      self.grid.place_agent(newBox,emptyGridPos)

    for i in range(self.emptyFloor):
      emptyGridPos = self.grid.find_empty()
      newFloor = Floor(i*self.emptyFloor+1000,emptyGridPos,False,self)
      self.schedule.add(newFloor)     
      self.grid.place_agent(newFloor,emptyGridPos)

    

    self.paver()
    self.datacollector = DataCollector(model_reporters={"Grid": get_grid})

  def paver(self):
    i = 0
    id = 0
    for j in range(self.nShelves):
      if j == self.W:
        i += 1
        j = 0
      newPos = (i,j)
      newFloor = Shelf( id , newPos, self)
      self.schedule.add(newFloor)
      self.grid.place_agent(newFloor,newPos)
      id += 1
      
    for i in range(5):
      emptyGridPos = (random.randint(0,self.W-1),random.randint(0,self.H-1))
      newRobot = Robot(i+100,emptyGridPos,self)
      self.schedule.add(newRobot)
      self.grid.place_agent(newRobot,emptyGridPos)

  
  def step(self):
    self.datacollector.collect(self)
    self.schedule.step()
    self.generations +=1
    if self.shelves == self.nBoxes:
      self.running = True