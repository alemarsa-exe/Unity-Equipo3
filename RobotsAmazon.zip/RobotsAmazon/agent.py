from mesa import Agent, Model 

from mesa.space import MultiGrid

from mesa.time import SimultaneousActivation

from mesa.datacollection import DataCollector

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as animation
plt.rcParams["animation.html"] = "jshtml"
matplotlib.rcParams['animation.embed_limit'] = 2**128

import numpy as np
import pandas as pd

import time
import datetime
import math
import random


def get_grid(model):
  grid = np.zeros((model.grid.width, model.grid.height))
  for cell in model.grid.coord_iter():
    cell_content, x, y = cell
    for content in cell_content:
      if isinstance(content,Shelf):
        grid[x][y] = content.stacks 
      elif isinstance(content,Robot):
        grid[x][y] =  9
      elif isinstance(content,Floor):
        if content.isBox:
          grid[x][y] = 7
        else:
          grid[x][y] = 8
      else:
        grid[x][y] = 6
  return grid


class Shelf(Agent):
  def __init__(self,unique_id, pos, model):
    super().__init__(unique_id,model)
    self.unique_id = unique_id
    self.pos = pos
    self.stacks = 0
    self.color = 10
    

class Floor(Agent):
  def __init__(self,unique_id, pos,isBox, model):
    super().__init__(unique_id,model)
    self.unique_id = unique_id
    self.pos = pos
    self.isBox = isBox

class Wall(Agent):
  def __init__(self,unique_id, pos, model):
    super().__init__(unique_id,model)
    self.unique_id = unique_id
    self.pos = pos


class Robot(Agent):
  def __init__(self,unique_id,pos,model):
    super().__init__(unique_id,model)
    self.hasBox = False
    self.inShelf = False
    self.pos = pos
    self.nextPosition = (0,0) 
    self.direction = 1 
  
  def nextMove(self, posToGo):
    if self.pos[0] > posToGo[0]: 
      if self.pos[1] > posToGo[1]:
        return (- 1, - 1)
      elif self.pos[1] < posToGo[1]: 
        return ( -1 , 1)
      else: 
        return (-1, 0)
    elif self.pos[0] < posToGo[0]: 
      if self.pos[1] > posToGo[1]: 
        return ( 1, - 1)
      elif self.pos[1] < posToGo[1]: 
        return (1 , 1)
      else: 
        return (1, 0)
    else: 
      if self.pos[1] > posToGo[1]: 
        return (0, - 1)
      elif self.pos[1] < posToGo[1]: 
        return (0, 1)
      else: 
        return (0, 0)

  
  def move(self):
    auxPos = (0,0)
    if not self.pos == self.nextPosition:
      nextSteps = self.nextMove(self.nextPosition)
      auxPos = (self.pos[0] + nextSteps[0],self.pos[1] + nextSteps[1])
    else:
      if self.pos[1] == self.model.W -1 and self.pos[0] == self.model.H-1 and self.model.H % 2==1:
        self.nextPosition = (0,0)
        auxPos = (self.pos)
      elif self.pos[1] == 0 and self.pos[0] == self.model.H-1 and self.model.H % 2==0:
        self.nextPosition = (0,0)
        auxPos = (self.pos)
      elif self.pos[1] == self.model.W -1 and self.direction == 1:
        auxPos = (self.pos[0]+1 , self.model.W -1)
        self.direction = -1
      elif self.pos[1] == 0 and self.direction == -1:
        auxPos = (self.pos[0]+1,0)
        self.direction = 1
      else:
        if self.direction == 1:
          auxPos = (self.pos[0],self.pos[1]+1)
        else:
          auxPos = (self.pos[0],self.pos[1]-1)
      self.nextPosition = auxPos 
    thisCell = self.model.grid.get_cell_list_contents([auxPos])
    robotsInCell = len([obj for obj in thisCell if isinstance(obj,Robot)])

    if robotsInCell > 0:
      occupied = True
      count = 0
      availableMoves = self.model.grid.get_neighborhood(self.pos, True, False)
      random.shuffle(availableMoves)
      while count < len(availableMoves) and occupied:
        thisCell = self.model.grid.get_cell_list_contents(availableMoves[count])
        robotsInCell = len([obj for obj in thisCell if isinstance(obj,Robot)])
        if robotsInCell == 0:
          auxPos = availableMoves[count]
          occupied = False
        else: 
          count +=1
       

    self.model.grid.move_agent(self, auxPos)
  

  def step(self):
    if self.hasBox:
      if self.pos == self.model.shelfPos: 
        thisCell = self.model.grid.get_cell_list_contents([self.pos])      
        shelf = [obj for obj in thisCell if isinstance(obj,Shelf)]
        shelf[0].stacks += 1
        self.model.shelves+=1
        self.hasBox = False
        if self.model.boxesLeft < 1:
          self.model.running = False
        if shelf[0].stacks == 5: 
          if self.model.shelfPos[1]== self.model.W -1:
            self.model.shelfPos = (self.model.shelfPos[0]+1,0)
          else:
            self.model.shelfPos = (self.model.shelfPos[0],self.model.shelfPos[1]+1)
      else: 
        nextSteps = self.nextMove(self.model.shelfPos)
        nextPos = (self.pos[0] + nextSteps[0],self.pos[1] + nextSteps[1])
        
        thisCell = self.model.grid.get_cell_list_contents(nextPos)
        hasRobot = len([obj for obj in thisCell if isinstance(obj,Robot)])
        if hasRobot == 0: 
          self.model.grid.move_agent(self, nextPos)
    else: 
      thisCell = self.model.grid.get_cell_list_contents([self.pos])
      thisFloor = [obj for obj in thisCell if isinstance(obj,Floor)] 
      if thisFloor[0].isBox == 1 and not thisFloor[0].pos == self.model.shelfPos:
        thisFloor[0].isBox = False 
        self.hasBox = True
        self.model.boxesLeft -= 1
      else:
        self.move()
