from mesa import Agent, Model 

# Se importa MultiGrid pues pueden existir varias entidades en una celda
from mesa.space import MultiGrid

# Con `SimultaneousActivation` hacemos que todos los agentes se activen de manera simultanea.
from mesa.time import SimultaneousActivation

# Vamos a hacer uso de `DataCollector` para obtener el grid completo cada paso (o generación) y lo usaremos para graficarlo.
from mesa.datacollection import DataCollector

# mathplotlib lo usamos para graficar/visualizar como evoluciona el autómata celular.
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as animation
plt.rcParams["animation.html"] = "jshtml"
matplotlib.rcParams['animation.embed_limit'] = 2**128

# Definimos los siguientes paquetes para manejar valores númericos.
import numpy as np
import pandas as pd

# Definimos otros paquetes que vamos a usar para medir el tiempo de ejecución de nuestro algoritmo.
import time
import datetime
import math
import random


def get_grid(model):
  #Se obtiene grid del modelo, se itera sobre la misma, se leen sus valores y se asigna un valor a cada celda para representación gráfica
  grid = np.zeros((model.grid.width, model.grid.height))
  for cell in model.grid.coord_iter():
    cell_content, x, y = cell
    for content in cell_content:
      if isinstance(content,Shelf):
        grid[x][y] = content.stacks 
      elif isinstance(content,Robot):
        grid[x][y] =  9
      elif isinstance(content,Floor):
        if content.isBox:
          grid[x][y] = 7
        else:
          grid[x][y] = 8
      else:
        grid[x][y] = 6
  return grid


class Shelf(Agent):
  def __init__(self,unique_id, pos, model):
    super().__init__(unique_id,model)
    self.unique_id = unique_id
    self.pos = pos
    self.stacks = 0
    self.color = 10

class Wall(Agent):
  def __init__(self,unique_id, pos, model):
    super().__init__(unique_id,model)
    self.unique_id = unique_id
    self.pos = pos
    self.stacks = 0
    self.color = 10
    

class Floor(Agent):
  def __init__(self,unique_id, pos,isBox, model):
    super().__init__(unique_id,model)
    self.unique_id = unique_id
    self.pos = pos
    self.isBox = isBox


class Robot(Agent):
  def __init__(self,unique_id,pos,model):
    super().__init__(unique_id,model)
    self.hasBox = False
    self.inShelf = False
    self.pos = pos
    self.nextPosition = (0,0) #Despues de dejar la primera caja comenzará a moverse desde esa posicion
    self.direction = 1 #1 derecha -1 izquierda
  
  def nextMove(self, posToGo):
    #Esta funcion se mueve como en diagonal, directo a la posToGo
    if self.pos[0] > posToGo[0]: #El robot sube
      if self.pos[1] > posToGo[1]: #Robot va a la izquierda
        return (- 1, - 1)
      elif self.pos[1] < posToGo[1]: #Robot va a la derecha
        return ( -1 , 1)
      else: #Se queda en su misma pos en X
        return (-1, 0)
    elif self.pos[0] < posToGo[0]: #El robot baja
      if self.pos[1] > posToGo[1]: #El robot va a la izquierda
        return ( 1, - 1)
      elif self.pos[1] < posToGo[1]: #El robot va a la derecha
        return (1 , 1)
      else: #Se queda en su misma pos en X
        return (1, 0)
    else: #Se queda en su misma pos en Y
      if self.pos[1] > posToGo[1]: # El robot va a la izquierda
        return (0, - 1)
      elif self.pos[1] < posToGo[1]: #El robot va a la derecha
        return (0, 1)
      else: #El robot no se mueve
        return (0, 0)

  
  def move(self):
    #Movimiento como serpientes y escaleras
    auxPos = (0,0)
    if not self.pos == self.nextPosition:
      nextSteps = self.nextMove(self.nextPosition)
      auxPos = (self.pos[0] + nextSteps[0],self.pos[1] + nextSteps[1])
    else:
      valid_neighborhood = [cell for cell in self.model.grid.iter_neighborhood(self.pos,True,False,1)]
      valid_neighborhood.extend([self.pos for _ in range(8-len(valid_neighborhood))])
      choices = valid_neighborhood
      auxPos = choices[np.random.choice(len(choices))]
      # #Llega a la posicion WxH
      # if self.pos[1] == self.model.W -1 and self.pos[0] == self.model.H-1 and self.model.H % 2==1:
      #   self.nextPosition = (0,0)
      #   auxPos = (self.pos)
      # elif self.pos[1] == 0 and self.pos[0] == self.model.H-1 and self.model.H % 2==0:
      #   self.nextPosition = (0,0)
      #   auxPos = (self.pos)
      # #está en la ultima columna y avanza hacia la derecha
      # elif self.pos[1] == self.model.W -1 and self.direction == 1:
      #   auxPos = (self.pos[0]+1 , self.model.W -1)
      #   self.direction = -1
      # elif self.pos[1] == 0 and self.direction == -1:
      #   auxPos = (self.pos[0]+1,0)
      #   self.direction = 1
      # #Avanzar si no se encuentra en las esquinas
      # else:
      #   valid_neighborhood = [cell for cell in self.model.grid.iter_neighborhood(self.pos,True,False,1)]
      #   valid_neighborhood.extend([self.pos for _ in range(8-len(valid_neighborhood))])
      #   choices = valid_neighborhood
      #   auxPos = choices[np.random.choice(len(choices))]
      self.nextPosition = auxPos 
    thisCell = self.model.grid.get_cell_list_contents([auxPos])
    robotsInCell = len([obj for obj in thisCell if isinstance(obj,Robot)])

    if robotsInCell > 0:
      occupied = True
      count = 0
      availableMoves = self.model.grid.get_neighborhood(self.pos, True, False)
      random.shuffle(availableMoves)
      while count < len(availableMoves) and occupied:
        thisCell = self.model.grid.get_cell_list_contents(availableMoves[count])
        robotsInCell = len([obj for obj in thisCell if isinstance(obj,Robot)])
        if robotsInCell == 0:
          auxPos = availableMoves[count]
          occupied = False
        else: 
          count +=1 

    #Test
    thisCell = self.model.grid.get_cell_list_contents([auxPos])
    detailWalls = [obj for obj in thisCell if isinstance(obj,Wall)]
    wallsInCell = len([obj for obj in thisCell if isinstance(obj,Wall)])


    if wallsInCell > 0:
      posWall = detailWalls[0].pos
      occupied = True
      count = 0
      availableMoves = self.model.grid.get_neighborhood(self.pos, True, False)
      availableMoves = [i for i in availableMoves if i != posWall]
      for i in availableMoves:
        checker = self.model.grid.get_cell_list_contents(i)
        for j in checker:
          if type(j) == Wall:
            availableMoves = [k for k in availableMoves if k != i]
      random.shuffle(availableMoves)
      random.shuffle(availableMoves)
      auxPos = random.choice(availableMoves)
      auxPos = (auxPos[0],auxPos[1]+1)
      self.nextPosition = auxPos 
        

    self.model.grid.move_agent(self, auxPos)
  

  def step(self):
    if self.hasBox:
      if self.pos == self.model.shelfPos: #Si está en el estante deja la caja si no está lleno
        thisCell = self.model.grid.get_cell_list_contents([self.pos])      
        shelf = [obj for obj in thisCell if isinstance(obj,Shelf)]
        shelf[0].stacks += 1
        self.model.shelves+=1
        self.hasBox = False
        if self.model.boxesLeft < 1:
          self.model.running = False
        if shelf[0].stacks == 10: #Si el estante esta lleno se cambia la posicion del estante
          if self.model.shelfPos[1] == self.model.W -1:
            self.model.shelfPos = (self.model.shelfPos[0]+1,0)
          else:
            self.model.shelfPos = (self.model.shelfPos[0],self.model.shelfPos[1]+1)
      else: #Tiene caja pero no ha llegado al estante
        nextSteps = self.nextMove(self.model.shelfPos)
        nextPos = (self.pos[0] + nextSteps[0],self.pos[1] + nextSteps[1])

        thisCell = self.model.grid.get_cell_list_contents(nextPos)
        hasWall = len([obj for obj in thisCell if isinstance(obj,Wall)])

        if hasWall > 0:
          nextPos = (self.pos[0] ,self.pos[1] + 1)
        
        thisCell = self.model.grid.get_cell_list_contents(nextPos)
        hasRobot = len([obj for obj in thisCell if isinstance(obj,Robot)])
        if hasRobot == 0: #Si no hay ningun robot se mueve a esa posicion, sino se espera 
          self.model.grid.move_agent(self, nextPos)
    else: #Si no tiene caja sigue buscando
      thisCell = self.model.grid.get_cell_list_contents(self.pos)
      thisFloor = [obj for obj in thisCell if isinstance(obj,Floor)] 
      if thisFloor[0].isBox == 1 and not thisFloor[0].pos == self.model.shelfPos:
        thisFloor[0].isBox = False 
        self.hasBox = True
        self.model.boxesLeft -= 1
      else:
        self.move()
