
from agent import Shelf, Floor, Robot, Wall

from mesa import Agent, Model 

# Se importa MultiGrid pues pueden existir varias entidades en una celda
from mesa.space import MultiGrid

# Con `SimultaneousActivation` hacemos que todos los agentes se activen de manera simultanea.
from mesa.time import SimultaneousActivation

# Vamos a hacer uso de `DataCollector` para obtener el grid completo cada paso (o generación) y lo usaremos para graficarlo.
from mesa.datacollection import DataCollector

# mathplotlib lo usamos para graficar/visualizar como evoluciona el autómata celular.
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as animation
plt.rcParams["animation.html"] = "jshtml"
matplotlib.rcParams['animation.embed_limit'] = 2**128

# Definimos los siguientes paquetes para manejar valores númericos.
import numpy as np
import pandas as pd

# Definimos otros paquetes que vamos a usar para medir el tiempo de ejecución de nuestro algoritmo.
import time
import datetime
import math
import random

def get_grid(model):
  #Se obtiene grid del modelo, se itera sobre la misma, se leen sus valores y se asigna un valor a cada celda para representación gráfica
  grid = np.zeros((model.grid.width, model.grid.height))
  for cell in model.grid.coord_iter():
    cell_content, x, y = cell
    for content in cell_content:
      if isinstance(content,Shelf):
        grid[x][y] = content.stacks 
      elif isinstance(content,Robot):
        grid[x][y] =  9
      elif isinstance(content,Floor):
        if content.isBox:
          grid[x][y] = 7
        else:
          grid[x][y] = 8
      else:
        grid[x][y] = 6
  return grid


class StorageModel(Model):
  def __init__(self, W, H, boxes):
    self.running = True
    self.nBoxes = boxes
    self.boxesLeft = boxes
    self.W = W
    self.H = H
    self.generations = 0
    self.nShelves = math.ceil(boxes / 5)
    self.shelves = 0
    self.shelfPos = (0,1)
    self.emptyFloor = W*H - boxes 
    self.kill_agents = []

    self.grid = MultiGrid(H,W,False)
    self.schedule = SimultaneousActivation(self)

    #Boxes
    for i in range(self.nBoxes):
      emptyGridPos = self.grid.find_empty()
      newBox = Floor(i+self.nShelves,emptyGridPos,True,self)
      self.schedule.add(newBox)     
      self.grid.place_agent(newBox,emptyGridPos)

    #Empty floor
    for i in range(self.emptyFloor):
      emptyGridPos = self.grid.find_empty()
      newFloor = Floor(i*self.emptyFloor+1000,emptyGridPos,False,self)
      self.schedule.add(newFloor)     
      self.grid.place_agent(newFloor,emptyGridPos)
    
    id = 10000
    for i in range(4):
      pos = (2, i+3)
      floors = self.grid.get_cell_list_contents(pos)
      for i in floors:
        if i.isBox:
          i.isBox = False
          self.nBoxes -= 1
          self.boxesLeft -= 1
      newWall = Wall(id,pos,self)
      self.schedule.add(newWall)     
      self.grid.place_agent(newWall,pos)
      id += 1
    
    for i in range(4):
      pos = (7, i+3)
      floors = self.grid.get_cell_list_contents(pos)
      for i in floors:
        if i.isBox:
          i.isBox = False
          self.nBoxes -= 1
          self.boxesLeft -= 1
      newWall = Wall(id,pos,self)
      self.schedule.add(newWall)     
      self.grid.place_agent(newWall,pos)
      
      id += 1
  

    self.paver()
    self.datacollector = DataCollector(model_reporters={"Grid": get_grid})

  def paver(self):
    #Shelves
    i = 0
    id = 0
    for j in range(self.nShelves):
      if j == self.W:
        i += 1
        j = 0
      newPos = (i,j)
      newFloor = Shelf( id , newPos, self)
      self.schedule.add(newFloor)
      self.grid.place_agent(newFloor,newPos)
      id += 1
      
    #Robots
    for i in range(5):
      emptyGridPos = (random.randint(0,self.W-1),random.randint(0,self.H-1))
      newRobot = Robot(i+100,emptyGridPos,self)
      self.schedule.add(newRobot)     
      self.grid.place_agent(newRobot,emptyGridPos)

    
      

  
  def step(self):
    self.datacollector.collect(self)
    self.schedule.step()
    self.generations +=1
    for x in self.kill_agents:
      self.grid.remove_agent(x)
      self.schedule.remove(x)
      self.kill_agents.remove(x)
    