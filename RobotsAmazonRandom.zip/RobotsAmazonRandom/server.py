from mesa.visualization.modules import CanvasGrid
from mesa.visualization.ModularVisualization import ModularServer
from mesa.visualization.UserParam import UserSettableParameter
import time
import numpy as np
import itertools
from agent import Shelf, Floor, Robot, Wall
from model import StorageModel

W = 10
H = 10
K = 15
EXEC_MAX_TIME = 0.05
model = StorageModel(W,H,K)
TIME_START = time.time() 

simulationParams = {
    "W": W,
    "H": H,
    "boxes": K,
}
'''
    "vacuums": UserSettableParameter(
        "slider",
        "Vacuums",
        3, #default
        1, #min
        20, #max
        1, #step
        description="Choose the number of vacuums.",
    ),
    "dirty_percentage": UserSettableParameter(
        "slider",
        "Dirty percentage",
        0.5, #default
        0.1, #min
        1, #max
        0.1, #step
        description="Choose the number of dirty percentage.",
    ),
    "exec_time": UserSettableParameter(
        "slider",
        "Execution time",
        100, #default
        10, #min
        10000, #max
        10, #step
        description="Choose the execution time.",
    ),
    '''

def agent_portrayal(agent):
    portrayal = {"Shape": "rect",
                    "Filled": "true",
                    "Color": "red",
                    "Layer": 1,
                    "w": 0,
                    "h": 0}
    if type(agent) is Shelf:
        portrayal = {"Shape": "rect",
                    "Filled": "true",
                    "Color": "gray",
                    "Layer": 0,
                    "r": 0.5,
                    "w": 1,
                    "h": 1}
    if type(agent) is Wall:
        portrayal = {"Shape": "rect",
                    "Filled": "true",
                    "Color": "black",
                    "Layer": 1,
                    "r": 0.5,
                    "w": 1,
                    "h": 1}
    if type(agent) is Robot:
        portrayal = {"Shape": "circle",
                    "Filled": "true",
                    "Color": "red",
                    "Layer": 0,
                    "r": 0.8}
    if type(agent) is Floor:
        if agent.isBox:
            portrayal = {"Shape": "rect",
                        "Filled": "true",
                        "Color": "brown",
                        "Layer": 0,
                        "r": 0.5,
                        "w": 0.4,
                        "h": 0.4}
        

    return portrayal

grid = CanvasGrid(agent_portrayal, 10, 10, 500, 500)



server = ModularServer(StorageModel,[grid],"Storage Model",simulationParams)
server.port = 8521
server.launch()